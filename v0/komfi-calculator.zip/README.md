# Komfi – Kalkulačka odměn pro obchodníky

Interaktivní React kalkulačka pro simulaci výdělků obchodních zástupců Komfi.

## Quick Start

```bash
# Komponenta je standalone React component
# Vyžaduje React 18+ a Tailwind CSS

# 1. Zkopíruj komfi-calculator.jsx do svého projektu
# 2. Importuj a použij:

import Calculator from './komfi-calculator';

function App() {
  return <Calculator />;
}
```

## Závislosti

- React 18+
- Tailwind CSS 3+

Komponenta nepoužívá žádné externí knihovny.

## Struktura odměňování

### Fixní složka
- **25 000 Kč/měsíc** – základní plat

### Progresivní provize za 1. měsíc

| Tier (noví klienti) | Provize |
|---------------------|---------|
| 0–20                | 10%     |
| 21–50               | 12%     |
| 51–100              | 15%     |
| 101–200             | 18%     |
| 201–400             | 20%     |
| 400+                | 22%     |

### Provize za 2.–6. měsíc
- **2%** z obratu klientů v portfoliu (jednotně)

## Logika výpočtů

### Klíčové konstanty

```javascript
const FIXED_SALARY = 25000;      // Fixní plat
const AVG_ORDER = 2000;          // Průměrná měsíční útrata klienta
const RETENTION = 0.5;           // Retence po 1. měsíci (50%)
const PORTFOLIO_COMMISSION = 0.02; // Provize z portfolia (2%)
```

### Výpočet měsíčního výdělku

```
Měsíční výdělek = Fixní plat 
                + (Noví klienti × Útrata × Tier%)
                + (Portfolio × Útrata × 2%)
```

### Portfolio

Portfolio = součet klientů z předchozích měsíců (M-1 až M-5), kteří:
1. Jsou v okně 2–6 měsíců od své akvizice
2. Aplikuje se 50% retence

### CPA (Cost Per Acquisition)

```
CPA = Celkový výdělek M1–6 / Počet získaných klientů
```

Zahrnuje fixní plat i všechny provize.

## Scénáře

### Konzervativní
Postupný růst přes menší partnery.

| Měsíc | Klientů | Partner |
|-------|---------|---------|
| 1     | 40      | 2× malá obec |
| 2     | 60      | 1× malá + 1× mini |
| 3     | 80      | 1× střední obec |
| 4     | 100     | 1× střední obec |
| 5     | 125     | 1× střední + 1× mini |
| 6     | 150     | 1× střední + 1× malá |

**Celkem:** 555 klientů

### Realistický
Střední tempo růstu.

| Měsíc | Klientů | Partner |
|-------|---------|---------|
| 1     | 50      | 1× malá obec |
| 2     | 100     | 1× střední obec |
| 3     | 200     | 1× velká obec |
| 4     | 300     | 1× velká + 1× střední |
| 5     | 400     | 2× velká obec |
| 6     | 500     | 1× město + 1× střední |

**Celkem:** 1 550 klientů

### Optimistický
Agresivní růst přes velké partnery.

| Měsíc | Klientů | Partner |
|-------|---------|---------|
| 1     | 100     | 1× střední obec |
| 2     | 200     | 1× velká obec |
| 3     | 400     | 2× velká obec |
| 4     | 600     | 1× město + 1× velká |
| 5     | 800     | 2× města |
| 6     | 1000    | 2× města + 1× velká |

**Celkem:** 3 100 klientů

## Typy partnerů (obcí)

| Typ | Obyvatel | Odhadovaný počet seniorů |
|-----|----------|--------------------------|
| 🏘️ Mini obec | ~1 000 | 20–50 |
| 🏡 Malá obec | ~3 000 | 50–100 |
| 🏢 Střední obec | 5 000–10 000 | 100–200 |
| 🏙️ Velká obec | 10 000–30 000 | 200–400 |
| 🌆 Město | 30 000+ | 400+ |

## Customizace

### Změna tierů

```javascript
const TIERS = [
  { min: 0, max: 20, percent: 10, label: '0–20' },
  { min: 21, max: 50, percent: 12, label: '21–50' },
  // ...
];
```

### Změna scénářů

```javascript
const SCENARIOS = {
  conservative: {
    name: 'Konzervativní',
    clients: [40, 60, 80, 100, 125, 150],  // klienti per měsíc
    partners: ['2× malá obec', ...],       // popis partnerů
  },
  // ...
};
```

### Změna konstant

```javascript
const FIXED_SALARY = 25000;  // Základní plat
const AVG_ORDER = 2000;      // Průměrná útrata
const RETENTION = 0.5;       // Retence (0-1)
```

## UI komponenty

- **Sticky taby** – přepínání scénářů, zůstávají viditelné při scrollu
- **Collapsible sekce** – typy partnerů (defaultně zavřená)
- **Tooltips** – kontextové nápovědy (komponenta `InfoTooltip`)
- **Tabulky s vysvětlivkami** – možnost skrýt/zobrazit

## Struktura souborů

```
komfi-calculator.jsx    # Hlavní komponenta
README.md               # Tato dokumentace
```

## Kontakt

Komfi Health s.r.o.  
IČ 09208241  
Korunní 2569/108, Praha 101 00

- **Luboš Buračinský** – CEO – lubos@komfi.health
- **Roman Bořánek** – Product Manager – roman@komfi.health
